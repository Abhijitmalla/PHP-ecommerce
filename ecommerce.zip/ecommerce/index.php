<?php
// Include database connection
include 'db/dbconnect.php';
session_start();

// Fetch featured products (you can customize this query as needed)
$sql = "SELECT * FROM Product LIMIT 10"; // Fetch top 10 products for display
$productResult = $conn->query($sql);

// Fetch categories for the sidebar (if needed)
$categorySql = "SELECT * FROM Category";
$categoryResult = $conn->query($categorySql);

// Check for query errors
if (!$productResult || !$categoryResult) {
    die("Query failed: " . $conn->error);
}

// Fetch products into an array
$products = $productResult->fetch_all(MYSQLI_ASSOC);

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple E-Commerce Website</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        header {
            background-color: #333;
            color: white;
            padding: 20px;
            position: relative;
        }
        .auth-buttons a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            padding: 5px 10px;
            border: 1px solid white;
            border-radius: 5px;
        }
        .product img {
            max-width: 100%;
            height: auto;
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
        }
        .product h2 {
            font-size: 1.5em;
            margin: 10px 0;
        }
        .product p {
            font-size: 1em;
            color: #555;
        }
        .product button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 10px 0;
            position: absolute;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>

<header class="d-flex justify-content-between align-items-center">
    <h1>Welcome to Our E-Commerce Store</h1>
    <div class="auth-buttons">
        <a href="user/login.php" class="btn btn-outline-light">Sign In</a>
        <a href="user/register.php" class="btn btn-outline-light">Sign Up</a>
    </div>
</header>

<div class="container mt-4">
    <div class="row">
        <?php if ($products): ?>
            <?php foreach ($products as $product): ?>
                <div class="col-md-4">
                    <div class="product card mb-4">
                        <img src="<?= htmlspecialchars($product['ProductImage']) ?>" alt="<?= htmlspecialchars($product['ProductName']) ?>" class="card-img-top">
                        <div class="card-body">
                            <h2 class="card-title"><?= htmlspecialchars($product['ProductName']) ?></h2>
                            <p class="card-text"><?= htmlspecialchars($product['ProductDescription']) ?></p>
                            <p class="card-text">$<?= number_format($product['ProductPrice'], 2) ?></p>
                            <button class="btn btn-success">Add to Cart</button>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No products available.</p>
        <?php endif; ?>
    </div>
</div>
<footer>
    <p>© 2024 Simple E-Commerce Store</p>
</footer>

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>



