<?php
// Include database connection
include '../db/dbconnect.php';

// Initialize variables to store user input and error messages
$username = $email = $password = $confirmPassword = $address = $gender = $profileImage = '';
$errors = [];

// You might want to include some validation and sanitization logic here
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="container">
        <h2>User Registration</h2>
        <?php
        if (!empty($errors)) {
            echo '<div class="errors">';
            foreach ($errors as $error) {
                echo '<p>' . htmlspecialchars($error) . '</p>';
            }
            echo '</div>';
        }
        ?>
        <form action="actions/register_submit.php" method="post" enctype="multipart/form-data">
            <div>
                <label for="username">Username:</label>
                <input type="text" name="username" id="username" value="<?php echo htmlspecialchars($username); ?>" required>
            </div>
            <div>
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            <div>
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
            </div>
            <div>
                <label for="confirm_password">Confirm Password:</label>
                <input type="password" name="confirm_password" id="confirm_password" required>
            </div>
            <div>
                <label for="address">Address:</label>
                <textarea name="address" id="address"><?php echo htmlspecialchars($address); ?></textarea>
            </div>
            <div>
                <label for="gender">Gender:</label>
                <select name="gender" id="gender" required>
                    <option value="">Select Gender</option>
                    <option value="Male" <?php if ($gender === 'Male') echo 'selected'; ?>>Male</option>
                    <option value="Female" <?php if ($gender === 'Female') echo 'selected'; ?>>Female</option>
                    <option value="Other" <?php if ($gender === 'Other') echo 'selected'; ?>>Other</option>
                </select>
            </div>
            <div>
                <label for="profile_image">Profile Image:</label>
                <input type="file" name="profile_image" id="profile_image" accept="image/*">
            </div>
            <div>
                <button type="submit">Register</button>
            </div>
        </form>
    </div>
</body>
</html>
