<?php
// Include database connection
include __DIR__ . '/../../db/dbconnect.php'; // Adjust this based on the actual path

// Start session to store errors
session_start();
$errors = [];

// Process the registration form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user input
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    $address = trim($_POST['address']);
    $gender = $_POST['gender'];

    // Validate input
    if (empty($username) || empty($email) || empty($password) || empty($confirmPassword) || empty($gender)) {
        $errors[] = "All fields are required.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    // Check for errors before proceeding
    if (empty($errors)) {
        // Hash the password for security
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

        // Handle profile image upload
        $profileImage = null; // Initialize as null
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == UPLOAD_ERR_OK) {
            $uploadDir = '../uploads/';
            // Create the uploads directory if it doesn't exist
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $profileImage = basename($_FILES['profile_image']['name']);
            $targetFilePath = $uploadDir . $profileImage;
            
            // Move uploaded file to the target directory
            if (!move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetFilePath)) {
                $errors[] = "Failed to upload profile image.";
            }
        }

        // Prepare the SQL query to insert the new user into the database
        $sql = "INSERT INTO User (UserName, Email, Password, Address, Gender, ProfileImage, RegistrationDate) 
                VALUES ('$username', '$email', '$hashedPassword', '$address', '$gender', '$profileImage', NOW())";

        // Execute the query
        if ($conn->query($sql) === TRUE) {
            // Successful registration, redirect to login page
            header("Location: ../login.php");
            exit();
        } else {
            $errors[] = "Error: " . $conn->error;
            header("Location: ../user_register.php");
            exit();
        
        }
    }

    // Store errors in session to display on the registration form
    $_SESSION['errors'] = $errors;
   // echo $_SESSION['errors'];
}
?>

