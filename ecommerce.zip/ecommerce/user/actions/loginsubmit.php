<?php
session_start();
include 'db_connect.php';
// Check if the user is already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php'); // Redirect to dashboard if logged in
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Escape user inputs for security
    $email = $conn->real_escape_string($_POST['email']);
    $username = $conn->real_escape_string($_POST['username']);
     // Check if email and password match
    $sql = "SELECT * FROM student WHERE email='$email' and username='$username'";
    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
             $_SESSION['user_id'] = $row['id'];
            header('Location: dashboard.php');
            exit();
        } else {
            $error = "Invalid email or password.";
        }
    $conn->close();
}
?>
