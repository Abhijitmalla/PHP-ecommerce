<?php
// Database connection parameters
$host = 'localhost';     // Your MySQL host (e.g., 'localhost')
$username = 'root';      // Your MySQL username
$password = '';          // Your MySQL password
$database = 'ecommerce_project1'; // The database name you want to create

// Create a connection to the MySQL server
$conn = new mysqli($host, $username, $password);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "successfull";

// Create the database
$sql = "CREATE DATABASE IF NOT EXISTS $database";
if ($conn->query($sql) === TRUE) {
  //  echo "Database '$database' created successfully or already exists.<br>";
} else {
    die("Error creating database: " . $conn->error);
}

// Select the database
if ($conn->select_db($database) === TRUE) {
//    echo "Successfully selected database '$database'.<br>";
} else {
    die("Error selecting database: " . $conn->error);
}

$conn = new mysqli($host, $username, $password, $database);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql_admin = "
CREATE TABLE Admin (
    AdminID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(100) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL
)";

// Execute the query
if ($conn->query($sql_admin) === TRUE) {
    echo "Table User created successfully";
} else {
echo "Error creating table: " . $conn->error;
}
$sql_user = "
CREATE TABLE IF NOT EXISTS User (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    UserName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Password VARCHAR(255) NOT NULL,
    Address TEXT,
    Gender ENUM('Male', 'Female', 'Other'),
    ProfileImage VARCHAR(255),
    RegistrationDate DATETIME DEFAULT CURRENT_TIMESTAMP
)";

// Execute the query
if ($conn->query($sql_user) === TRUE) {
   // echo "Table User created successfully";
} else {
  //  echo "Error creating table: " . $conn->error;
}

$sql_category = "
CREATE TABLE IF NOT EXISTS Category (
    CategoryID INT AUTO_INCREMENT PRIMARY KEY,
    CategoryName VARCHAR(100) NOT NULL
)";

// Execute the query
if ($conn->query($sql_category) === TRUE) {
   // echo "Table User created successfully";
} else {
   // echo "Error creating table: " . $conn->error;
}

$sql_product = "
CREATE TABLE IF NOT EXISTS Product (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(100) NOT NULL,
    ProductDescription TEXT,
    ProductPrice DECIMAL(10, 2) NOT NULL,
    CategoryID INT,
    ProductImage VARCHAR(255),
    FOREIGN KEY (CategoryID) REFERENCES Category(CategoryID)
)";

// Execute the query
if ($conn->query($sql_product) === TRUE) {
   // echo "Table User created successfully";
} else {
   // echo "Error creating table: " . $conn->error;
}

$sql_order = "
CREATE TABLE `Order` (
    OrderID INT AUTO_INCREMENT PRIMARY KEY,
    OrderDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    UserID INT,
    TotalAmount DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (UserID) REFERENCES User(UserID)
)
";

// Execute the query
if ($conn->query($sql_order) === TRUE) {
   // echo "Table User created successfully";
} else {
//echo "Error creating table: " . $conn->error;
}

$sql_orderdetails = "
CREATE TABLE OrderDetails (
    OrderDetailID INT AUTO_INCREMENT PRIMARY KEY,
    OrderID INT NOT NULL,
    ProductName VARCHAR(100) NOT NULL,
    ProductPrice DECIMAL(10, 2) NOT NULL,
    Quantity INT NOT NULL,
    Total DECIMAL(10, 2) NOT NULL,
    Date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (OrderID) REFERENCES `Order`(OrderID) ON DELETE CASCADE
)";

// Execute the query
if ($conn->query($sql_orderdetails) === TRUE) {
   // echo "Table User created successfully";
} else {
  //  echo "Error creating table: " . $conn->error;
}
$sql_payment = "
CREATE TABLE Payment (
    PaymentID INT AUTO_INCREMENT PRIMARY KEY,
    OrderID INT,
    PaymentDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    PaymentAmount DECIMAL(10, 2) NOT NULL,
    PaymentMethod VARCHAR(50),
    PaymentStatus VARCHAR(50),
    FOREIGN KEY (OrderID) REFERENCES `Order`(OrderID)
)
";

// Execute the query
if ($conn->query($sql_payment) === TRUE) {
   // echo "Table User created successfully";
} else {
  //  echo "Error creating table: " . $conn->error;
}

$sql_review = "
CREATE TABLE Review (
    ReviewID INT AUTO_INCREMENT PRIMARY KEY,
    ProductID INT,
    UserID INT,
    Rating TINYINT NOT NULL CHECK (Rating BETWEEN 1 AND 5),
    ReviewText TEXT,
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
    FOREIGN KEY (UserID) REFERENCES User(UserID)
)
";

// Execute the query
if ($conn->query($sql_review) === TRUE) {
   // echo "Table User created successfully";
} else {
   // echo "Error creating table: " . $conn->error;
}

?>

